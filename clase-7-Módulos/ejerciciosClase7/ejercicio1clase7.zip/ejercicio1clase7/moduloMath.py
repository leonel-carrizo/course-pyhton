def sumar(a, b):
    '''Suma los valores a y b indicados en la instancia'''
    return a + b


def restar(a, b):
    '''Resta los valores a y b indicados en la instancia'''
    return a - b


def multiplicador(a, b):
    '''Multiplica los valores a y b indicados en la instancia'''
    return a * b


def dividir(a, b):
    '''Divide los valores a y b indicados en la instancia'''
    return a / b
