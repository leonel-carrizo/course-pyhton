from django.apps import AppConfig


class FilmdirectorsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'filmDirectors'
