for numeros in range(100, 0, -1):

    print(numeros)