edad = int(input('Por favor ingrese su edad: '))

if edad >= 18:
    print('Eres mayor de edad!')
else:
    print('Todavía eres menor de edad')