inicio = -6
final = 11
for numero in range(inicio,final):
    if numero % 2 != 0:
        print( numero)
